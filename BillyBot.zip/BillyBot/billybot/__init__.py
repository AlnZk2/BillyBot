"""BillyBot - bot de Discord para o RPG Subsolo 57."""

__version__ = "2.0.0"
